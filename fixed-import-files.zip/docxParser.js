const mammoth = require('mammoth');

/**
 * FLEXIBLE Word Document Parser for Traffic Law Questions
 * 
 * Supports MULTIPLE formats in the same document:
 * 
 * FORMAT 1 (Full trilingual):
 * Q: What does a red traffic light mean?
 * Q_RW: Urumuri rutukura rusobanura iki?
 * Q_FR: Que signifie un feu rouge?
 * A: Stop completely | Hagarara burundu | Arrêt complet
 * B: Slow down | Gabanya umuvuduko | Ralentir
 * C: Proceed with caution | Komeza wifashije | Avec prudence
 * D: Honk and go | Vuga inziga | Klaxonner
 * ANS: A
 * CAT: Traffic Rules
 * DIFF: easy
 * ---
 * 
 * FORMAT 2 (English only - system reuses EN for RW and FR):
 * Q: What does a red traffic light mean?
 * A: Stop completely
 * B: Slow down
 * C: Proceed with caution
 * D: Honk and go
 * ANS: A
 * ---
 * 
 * FORMAT 3 (Numbered questions - common in Rwanda exam books):
 * 1. What does a red traffic light mean?
 * A. Stop completely
 * B. Slow down
 * C. Proceed with caution
 * D. Honk and go
 * ANSWER: A
 * ---
 */

const parseDocxQuestions = async (filePath) => {
  let rawText = '';
  
  try {
    const result = await mammoth.extractRawText({ path: filePath });
    rawText = result.value;
    console.log('📄 Extracted text length:', rawText.length, 'characters');
    console.log('📄 First 500 chars preview:\n', rawText.substring(0, 500));
  } catch (err) {
    throw new Error('Could not read Word file: ' + err.message);
  }

  if (!rawText || rawText.trim().length < 10) {
    throw new Error('Word document appears to be empty or unreadable');
  }

  const questions = [];

  // Try Format 1 & 2 first (key: value style)
  const keyValueQuestions = parseKeyValueFormat(rawText);
  if (keyValueQuestions.length > 0) {
    console.log(`✅ Key-value format: found ${keyValueQuestions.length} questions`);
    questions.push(...keyValueQuestions);
  }

  // If nothing found, try numbered format
  if (questions.length === 0) {
    const numberedQuestions = parseNumberedFormat(rawText);
    if (numberedQuestions.length > 0) {
      console.log(`✅ Numbered format: found ${numberedQuestions.length} questions`);
      questions.push(...numberedQuestions);
    }
  }

  // If still nothing, try loose format (just grab what we can)
  if (questions.length === 0) {
    const looseQuestions = parseLooseFormat(rawText);
    if (looseQuestions.length > 0) {
      console.log(`✅ Loose format: found ${looseQuestions.length} questions`);
      questions.push(...looseQuestions);
    }
  }

  console.log(`📊 Total parsed: ${questions.length} questions`);
  return questions;
};

// ─── FORMAT 1 & 2: Key:Value style ──────────────────────────────────────────
const parseKeyValueFormat = (text) => {
  const questions = [];

  // Split by separator lines or double newlines
  const blocks = text
    .split(/\n\s*[-─=*]{3,}\s*\n|\n{3,}/)
    .map((b) => b.trim())
    .filter((b) => b.length > 10);

  for (const block of blocks) {
    try {
      const q = parseOneKeyValueBlock(block);
      if (q) questions.push(q);
    } catch (e) {
      console.log('Skipped block:', e.message);
    }
  }

  return questions;
};

const parseOneKeyValueBlock = (block) => {
  const lines = block.split('\n').map((l) => l.trim()).filter(Boolean);

  let question_en = '', question_rw = '', question_fr = '';
  const options = [];
  let correct_answer = '';
  let category = '';
  let difficulty = 'medium';

  for (const line of lines) {
    // Try to detect key: value pattern
    const colonIdx = line.indexOf(':');
    if (colonIdx === -1) continue;

    const rawKey = line.substring(0, colonIdx).trim().toUpperCase().replace(/\s+/g, '_');
    const value = line.substring(colonIdx + 1).trim();

    if (!value) continue;

    switch (rawKey) {
      case 'Q':
      case 'QUESTION':
      case 'QUESTION_EN':
      case 'Q_EN':
        // If we hit a new Q and already have one, this block has multiple — skip
        question_en = value;
        break;
      case 'Q_RW':
      case 'QRW':
      case 'QUESTION_RW':
        question_rw = value;
        break;
      case 'Q_FR':
      case 'QFR':
      case 'QUESTION_FR':
        question_fr = value;
        break;
      case 'A':
      case 'B':
      case 'C':
      case 'D': {
        const parts = value.split('|').map((p) => p.trim());
        options.push({
          letter: rawKey,
          en: parts[0] || value,
          rw: parts[1] || parts[0] || value,
          fr: parts[2] || parts[1] || parts[0] || value,
        });
        break;
      }
      case 'ANS':
      case 'ANSWER':
      case 'CORRECT':
      case 'CORRECT_ANSWER':
      case 'KEY':
        correct_answer = value.trim().toUpperCase().charAt(0);
        break;
      case 'CAT':
      case 'CATEGORY':
        category = value;
        break;
      case 'DIFF':
      case 'DIFFICULTY':
      case 'LEVEL':
        difficulty = value.toLowerCase().includes('easy') ? 'easy'
          : value.toLowerCase().includes('hard') ? 'hard' : 'medium';
        break;
    }
  }

  // Validate
  if (!question_en) return null;
  if (options.length < 2) return null;
  if (!correct_answer) return null;

  // Fill missing languages with EN
  if (!question_rw) question_rw = question_en;
  if (!question_fr) question_fr = question_en;

  // Ensure we have A,B,C,D - pad if needed
  const letters = ['A', 'B', 'C', 'D'];
  while (options.length < 4) {
    const nextLetter = letters[options.length];
    options.push({ letter: nextLetter, en: 'N/A', rw: 'N/A', fr: 'N/A' });
  }

  return { question_en, question_rw, question_fr, options: options.slice(0, 4), correct_answer, category, difficulty };
};

// ─── FORMAT 3: Numbered style (1. Question\nA. Option) ──────────────────────
const parseNumberedFormat = (text) => {
  const questions = [];
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);

  let current = null;

  const saveQuestion = () => {
    if (current && current.question_en && current.options.length >= 2 && current.correct_answer) {
      // Pad to 4 options
      while (current.options.length < 4) {
        current.options.push({ letter: ['A','B','C','D'][current.options.length], en: 'N/A', rw: 'N/A', fr: 'N/A' });
      }
      questions.push({ ...current });
    }
  };

  for (const line of lines) {
    // Detect numbered question: "1." or "1)" or "Q1."
    const numMatch = line.match(/^(?:Q\s*)?(\d+)[.)]\s+(.+)/i);
    // Detect option: "A." or "A)" or "(A)"
    const optMatch = line.match(/^[(\[]?([A-D])[.)[\]]\s+(.+)/i);
    // Detect answer: "Answer: A" or "Correct: B" or "Key: C" or just "A" on its own line after options
    const ansMatch = line.match(/^(?:ans(?:wer)?|correct(?:\s+answer)?|key|rep[oô]nse)\s*[:\-]?\s*([A-D])\b/i)
      || line.match(/^([A-D])\s*$/) // just a letter alone

    if (numMatch) {
      saveQuestion();
      current = {
        question_en: numMatch[2].trim(),
        question_rw: numMatch[2].trim(),
        question_fr: numMatch[2].trim(),
        options: [],
        correct_answer: '',
        category: '',
        difficulty: 'medium',
      };
    } else if (optMatch && current) {
      const letter = optMatch[1].toUpperCase();
      const text = optMatch[2].trim();
      // Check if option already exists
      if (!current.options.find((o) => o.letter === letter)) {
        current.options.push({ letter, en: text, rw: text, fr: text });
      }
    } else if (ansMatch && current) {
      current.correct_answer = ansMatch[1].toUpperCase();
    }
  }

  saveQuestion();
  return questions;
};

// ─── FORMAT 4: Loose/unstructured — grab what we can ────────────────────────
const parseLooseFormat = (text) => {
  const questions = [];
  // Split into paragraphs
  const paragraphs = text.split(/\n{2,}/).map((p) => p.trim()).filter((p) => p.length > 20);

  for (let i = 0; i < paragraphs.length; i++) {
    const para = paragraphs[i];
    // If it looks like a question (ends with ?) and next para has A. B. C. D.
    if (para.includes('?') || /^\d+\./.test(para)) {
      const questionText = para.replace(/^\d+\.\s*/, '').trim();
      const optBlock = paragraphs[i + 1] || '';

      // Look for A, B, C, D in the option block
      const optMatches = [...optBlock.matchAll(/([A-D])[.)]\s+(.+?)(?=\n[A-D][.)]|\n*$)/gs)];

      if (optMatches.length >= 2) {
        const options = optMatches.slice(0, 4).map((m) => ({
          letter: m[1].toUpperCase(),
          en: m[2].trim(),
          rw: m[2].trim(),
          fr: m[2].trim(),
        }));

        // Pad to 4
        while (options.length < 4) {
          options.push({ letter: ['A','B','C','D'][options.length], en: 'N/A', rw: 'N/A', fr: 'N/A' });
        }

        questions.push({
          question_en: questionText,
          question_rw: questionText,
          question_fr: questionText,
          options,
          correct_answer: 'A', // Default - admin can correct later
          category: '',
          difficulty: 'medium',
        });
        i++; // Skip options block
      }
    }
  }

  return questions;
};

module.exports = { parseDocxQuestions };
